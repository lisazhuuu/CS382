/*          Mingfang Zhu
            Nov 18, 2023
            Lab9

            Description of Program:
                This lab is to build a compiler program
                It should input from users, parse it, and create machine code based the input and rules
                It also creates symbol table to keep track of all the functions, variables, etc.

            Description of File: 
                This is the header file of emit.c, and it declares some of the functions that will be used
                    Including EMIT(), EMIT_GLOBALS(), EMIT_STRINGS(), and emit()
                It defines two global variables WSIZE and LOB_WSIZE
                    WSIZE is the word size, and LOB_WSIZE is the base 2 log of it
                It includes ast.h in so that the handshake between this and the AST will be working 

            Changes: 
                - Included "ast.h"
                - Added function header for EMIT_GLOBALS(), EMIT_STRINGS, and emit()
*/
#ifndef EMIT_H
#define EMIT_H
#include "ast.h"

#define WSIZE 4 // Word size: 4 bytes
#define LOB_WSIZE 2 // Base 2 log

void EMIT(ASTnode * p, FILE * fp); // Like ASTPrint, but to file descriper
void EMIT_GLOBALS(ASTnode * p, FILE * fp); // This function deals with global variables
void EMIT_STRINGS(ASTnode * p, FILE * fp); // This function deals with writting strings
 // This function takes a file pointer, 3 char pointers that have label, command, and comment
 // It prints the lines out on .asm file with specific format
void emit(FILE * fp, char * label, char * command, char * comment); 

#endif