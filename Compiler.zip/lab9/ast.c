 /*        Mingfang Zhu
            Nov 18, 2023
            Lab9

            Description of Program:
                This lab is to build a compiler program
                It should input from users, parse it, and create machine code based the input and rules
                It also creates symbol table to keep track of all the functions, variables, etc.

            Description of File: 
                This file uses the node type that was created in yacc file to print out Abstract Syntax Tree.
                It also connects the s1 and s2 between different nodes.
                This file has methods to print out white space and AST, and methods to convert data type of nodes into string.
                It checks the difference between formal and actual parameters as well, and return the result by 0 (same) and 1 (different)
                The new function CreateLabel() was added to create temporary label to print out in machine code

            Changes: 
                - Added CreateLabel() to create and print out temporary label in asm file if needed
   */

   /*   Mingfang Zhu
        Oct 29, 2023
        Lab7

        Description: 
                - Add symbol table code to the semantic action set. 
                - Ensure that used variables have been declared. 
                - Assign new symbols to intermeidate values in expressions
                - Add type checking to not mix void and int

        This file contains different operation methods for Abstract Syntax Tree
        Including Create Node, Print White Space, Print Datatype, and Print AST

        Changes: 
            - Include "symtable.h"
            - Moify the print statements for datatypes including A_VARDEC, so that 
                It prints out the offset as well
            - Add method check_param, so that
                It returns 1 if formal param and actual param have same length and same type for each element,
                Otherwise it returns 0
*/
/*      Mingfang Zhu
        Oct 13, 2023
        Lab6

        This lab checks whether the syntax of program is correct, and creates a simple Abstract Syntax Tree.
        This file contains methods that create node, print white spaces, print datatype, and print the tree.
        
        - Completed the PT method, which prints out the appropriate amount of white spaces
        - Add boolean type to DataTyptToString so that it can recognize the boolean type
        - Add switch cases for the A nodes
*/

/* Abstract syntax tree code
This code is used to define an AST node,
routine for printing out the AST
defining an enumerated nodetype so we can figure out what we need to
do with this. The ENUM is basically going to be every non-terminal
and terminal in our language.
Shaun Cooper February 2023
*/
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include "ast.h"
#include "symtable.h"
#include <string.h>

int count = 0;

/* uses malloc to create an ASTnode and passes back the heap address of the newley
created node */
// PRE: Data type of the node that will be created
// POST: A new ASTnode with given datatype
ASTnode *ASTCreateNode(enum ASTtype mytype) // Start of *ASTCreateNode()
{
    ASTnode *p; // Create a node pointer p

    if (mydebug) {
        fprintf(stderr,"Creating AST Node \n");
    }
    
    p=(ASTnode *)malloc(sizeof(ASTnode)); // Allocate memory for an ASTnode and assign its address to the pointer p
    
    p->nodetype=mytype; // Update type
    
    p->s1=NULL; // Set s1 to null
    p->s2=NULL; // Set s2 to null
    p->value=0; // Set value to 0
    
    return(p);
} // End of *ASTCreateNode()

/* Helper function to print tabbing */
// PRE: Receive an positive integer
// POST: Print out that integer's amount of whitespace
void PT(int howmany) // Start of PT
{
    if (howmany > 0) // Start of if statement
    { // If number of space is positive
        for (int i = 0; i < howmany; i++) // Start of while loop
        {
            printf(" "); // Print this amount of white spaces
        } // End of while loop
    }// End of if statement
    return;
} // End of PT

// PRE: a Data Type
// POST: a character string for that type to print nicely -- caller does final
// output
// Helper method that changes datatype to string
char * DataTypeToString(enum DataTypes mydatatype)
{ // Start of function
    switch (mydatatype) // Start of switch
    {
        case A_VOIDTYPE: // Case 1
            return ("void"); // Return void
            break;
        case A_INTTYPE: // Case 2
            return ("int"); // Return int
            break;
         case A_BOOTYPE: // Case 3
            return ("boolean"); // Return boolean
            break;

        default: printf("Unknown type in DataTypeToString\n"); // Print out message if datatype is none of those
        exit(1);
    } // End of switch
} // End of function

/* Print out the abstract syntax tree */
// PRE: Pointer to an AST tree
// PST: Print formatted tree output
void ASTprint(int level,ASTnode *p)
{ // Start of function
    int i;

    if (p == NULL ) // When given node is null
    { // Start of if statement
        return; // Return directly
    } // End of if statement
    // when here p is not NULL
    switch (p->nodetype) // Start of switch
    { // Start of switch statement
        // Declaration list
        case A_DEC_LIST: // When seeing A_DEC_LIST node
            ASTprint(level,p->s1); // Print out its s1 and s2
            ASTprint(level,p->s2);
            break;

        // Statement list
        case A_STMT_LIST: // When seeing A_STMT_LIST node
            ASTprint(level,p->s1); // Print out its s1 and s2
            ASTprint(level,p->s2);
            break;
            
        // Local Declaration
        case A_LOCAL_DEC:
            ASTprint(level, p->s1);
            ASTprint(level, p->s2);
            break;

        // Expression statement
        case A_EXPRSTMT: // When seeing A_EXPRSTMT node
            PT(level); // Indent
            printf("Expression Statement\n");
            ASTprint(level+1, p->s1); // Same indentation and print out its s1
            break;

        // Parameter list
        case A_PARAMLIST: // When seeing A_PARAMLIST node
            ASTprint(level+1,p->s1); // Print out its s1
            printf("\n"); // Pring out new line
            ASTprint(level,p->s2); // Print out its s2
            break;

        // Parameters
        case A_PARAMS: // When seeing A_PARAMLIST node
            if (p->s1 == NULL)
            { // If the data has void type
                PT(level+1);
                printf("VOID\n"); // Print out void
            } else { // If its not void
                PT(level); 
                printf("\n");
                ASTprint(level,p->s1); // Print out its s1
                PT(level);
            }
            break;

        // Parameter
        case A_PARAM: // When seeing A_PARAM node
            PT(level);
            printf("PARAMETER ");
            printf("%s ", DataTypeToString(p->datatype));
            printf("%s", p->name);
            if (p->value == -1) {
                printf("[]");
            }
            printf(" with offset %d ", p->symbol->offset );
            printf("and level %d\n", level);
            ASTprint(level, p->s1);
            break;

        // Number
        case A_NUM: // NUM is a leaf
            PT(level); // Print out this number's value
            printf("NUMBER with value %d\n", p -> value);
            break;

        // Variable
        case A_VAR: // When seeing A_VAR node
            PT(level); 
            if (p->s1 != NULL) // If it has s1
            { // Print out the name
                printf("VARIABLE %s", DataTypeToString(p->datatype));
                printf("%s with offset %d and level %d \n", p->name, p->symbol->offset, p->symbol->level);
                PT(level+1);
                printf("[\n");
                ASTprint(level+2, p->s1);
                PT(level+1);
                printf("]\n"); // Print out [] with its value in it
            } else {
               printf("VARIABLE %s ", DataTypeToString(p->datatype));
               printf("%s with offset %d and level %d \n", p->name, p->symbol->offset, p->symbol->level);  // Just print out the variable's name
            }
            break;

        // Expression
        case A_EXPR: // When seeing an expression
            PT(level); 
             // Switch cases with different operators
            switch (p->operator) // It prints out each of operators
            { // Start of switch
                case A_PLUS:
                    printf("Expression +\n");
                    break;

                case A_MINUS:
                    printf("Expression -\n");
                    break;

                case A_TIMES:
                    printf("Expression *\n");
                    break;

                case A_DIV:
                    printf("Expression /\n");
                    break;

                case A_AND:
                    printf("Expression and\n");
                    break;

                case A_OR:
                    printf("Expression or\n");
                    break;

                case A_LEQ:
                    printf("Expression <=\n");
                    break;

                case A_LT:
                    printf("Expression <\n");
                    break;

                case A_GT:
                    printf("Expression >\n");
                    break;

                case A_GEQ:
                    printf("Expression >=\n");
                    break;

                case A_EQT:
                    printf("Expression ==\n");
                    break;

                case A_NEQ:
                    printf("Expression !=\n");
                    break;

                case A_NOT:
                    printf("Expression not\n");
                    break;

                default: printf("Unknown operator in A_EXPR ASTprint\n"); // Default case when the operator is unknown
                exit(1);
            } // Start of switch
            ASTprint(level+1, p->s1); // Print out its s1 and s2 with proper indentation
            ASTprint(level+1, p->s2);
            break;

        // Assignment statement
        case A_ASSIGN: // When seeing A_ASSIGN
            PT(level);
            printf("ASSIGMENT STATEMENT \n");
            
            PT(level+1); 
            printf("LEFT:\n"); // Print out the left side (s1)
            ASTprint(level+2, p -> s1);	//Var

            PT(level+1); // Properly indent
            printf("RIGHT:\n");
            ASTprint(level+2, p -> s2); // Print out the right side (s2)
            break;

        // Writing statement
        case A_WRITE: // When seeing A_WRITE 
            PT(level);
            printf("Write ");
            if (p->name != NULL) { // If its a string
                printf("%s \n", p->name); // Print out its name
            } else { // Expression
                printf("\n");
                ASTprint(level+1, p->s1); // Print out its s1
            }
            break;

        // Variable declaration
        case A_VARDEC: // When seeing A_VARDEC
            PT(level);
            printf("Variable ");
            printf("%s ", DataTypeToString(p->datatype)); // Print out the datatype
            printf("%s",p->name); // Print out its name
            if (p->value > 0) // If the length of array is greater than 0
                printf("[%d]",p->value); // Print it out inside []
            printf(" with offset %d ", p->symbol->offset);
            printf("and level %d ", level);
            printf("\n"); 
            ASTprint(level,p->s1); // Print out its s1
            break;

        // Function declaration
        case A_FUNDEC : // When seeing A_FUNDEC
            PT(level);
            printf("Function ");
            printf("%s ", DataTypeToString(p->datatype)); // Print out its datatype
            printf("%s ",p->name); // Print out its name
            printf("with offset %d", p->symbol->offset); // Print out its name
            PT(level+1);
            printf("(\n");
            ASTprint(level+2,p->s1); // Parameters
            PT(level+1);
            printf(")\n");
            ASTprint(level+1,p->s2); // Compound statement
            printf("\n");
            break;

        // Compound statement
        case A_COMPOUND : // When seeing A_COMPOUND
            PT(level);
            printf("BEGIN\n");
            ASTprint(level+1,p->s1); // Print out its local variable
            ASTprint(level+1,p->s2); // Pring out its statement list
            PT(level);
            printf("END\n");
            break;

        // Iteration statement
        case A_ITERATION: // When seeing A_ITERATION
            PT(level);
            printf("While\n");
            ASTprint(level + 1, p -> s1); // Print out expression
            PT(level + 1);
            printf("DO \n");
            ASTprint(level + 2, p -> s2); // Print out statement
            break;

        // Call statement
        case A_CALL: // When seeing A_CALL
            PT(level);
            printf("CALL %s\n", p->name); // Print out its name
            PT(level+1);
            printf("(\n");
            ASTprint(level+2,p->s1); // Print out arguments
            PT(level+1);
            printf(")\n");
            break;

        // Argument list
        case A_ARGLIST: // When seeing A_ARGLIST
            PT(level);
            printf("CALL ARGUMENT\n"); 
            ASTprint(level+1,p->s1); // Print out expression
            ASTprint(level,p->s2); // Print out other arguments
            break;

        // Arguments
        case A_ARGS: // When seeing A_ARGS
            ASTprint(level+1,p->s1); // Print out its s1
            break;

        // Selection statement
        case A_SELECTION: // When seeing A_SELECTION
            PT(level); 
            printf("IF \n");
            ASTprint(level+1, p->s1); // Print out if statement
            PT(level+1);
            printf("IF Body \n");
            ASTprint(level+2, p->s2); // Print out if body
            break;

        // If statement
        case A_IFSTMT: // When seeing A_IFSTMT
            ASTprint(level, p->s1); // Print out the body of if statement
            if(p->s2 != NULL){ // If there's else statement part
                PT(level-1);
                printf("ELSE \n");
                ASTprint(level, p->s2); // Print out the else statement
            } //end of if
            break;

        // Read statement
        case A_READ: // When seeing A_READ
            PT(level);
            printf("READ: \n");
            ASTprint(level+1, p->s1); // Print out variable
            break;

        // Return statement
        case A_RETURN: // When seeing A_RETURNSTMT
            PT(level); 
            printf("RETURN: \n");
            if (p->s1 != NULL) {
                ASTprint(level + 1, p->s1); // Print out expression
            }
            printf("\n");
            break;
        
        default: 
            printf("unknown type in ASTprint %d\n", p->nodetype); // Debug: Print out the unknown type
            printf("Exiting ASTprint immediately\n");
            exit(1);
    } // End of switch statement
} // End of function

// This method takes 2 lists of AST of parameters, and compare them
// Pre: 2 lists of AST of parameters are given
// Post: Returns 1 if formal param and actual param have same length and same type for each element
//       Otherwise, return 0
int check_params(ASTnode *formals, ASTnode *actuals) 
{ // Start of function
  // Case 1: When both are null, return 1
  if (formals == NULL && actuals == NULL) { // Start of if statement
    return 1; 
  } // End of if statement
  // Case 2, When 1 of them are null, return 0
  if (formals == NULL || actuals  == NULL) {  // Start of if statement
        // One is null 0
        if (formals != NULL && formals->datatype == A_VOIDTYPE) { // Start of if statement
            return 1; // But if parameter is void type and arguments are null, return 1
        } // End of if statement
    return 0;
  }  // End of if statement
  // Case 3: When datatypes or values of two formal and actual are different, return 0
  if ((formals -> datatype != actuals -> datatype)) { // Start of if statement
    // Same type or not 0
    return 0;
  }  // End of if statement
  // Otherwise, keep checking parameters
  return check_params(formals->s1, actuals->s2);
} // End of function

// This function creates label so that the label (in form of char* string pointer) can be created and printed out in asm file
// PRE: None
// POST: A char string pointer (ie. _L0) will be returned when calling this function
char * createLable() { // Start of function
    char cArray[100]; // Create a char array with 100 space to store label
    char * pointer = cArray; // Set a pointer to the array
    char * s; // Create another char string pointer
    sprintf(cArray, "_L%d", count++); // Store the line num on the array and increment the counter
    s = strdup(cArray); // Point s to char array
    return (s); // Return the pointer
} // End of function

/* dummy main program so I can compile for syntax error independently
main()
{
}
/* */

