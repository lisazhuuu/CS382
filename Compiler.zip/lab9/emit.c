/*          Mingfang Zhu
            Nov 18, 2023
            Lab9

            Description of Program:
                This lab is to build a compiler program
                It should input from users, parse it, and create machine code based the input and rules
                It also creates symbol table to keep track of all the functions, variables, etc.

            Description of File: 
                This gets the nodetype from yacc file, and result of node's existance from symtable
                It creates a .asm file, and output the code for machine into that file based on user's input
                It should be able to take a command from user about a test code file, as well as
                    a file name that can be created with postfix .asm to output the machine code

            Changes: 
                - Updated EMIT() so that it prints out the head part of .asm file,
                    it calls the helper functions EMIT_STRINGS() and EMIT_GLOBALS() to deal with global variables and writing string
                - Created EMIT_GLOBALS() and EMIT_STRING() to deal with global variables and writing string
                - Created emit() function to print out label, command, and comment in output file with specific format
                - Created emit_ast() function so that it has all the possible nodes for switch cases
                    It uses different helper functions for different nodetypes for different input that user types
                - Created all the helper functions for different nodetypes
                    Including emit_function_dec(), emit_function_dec(), emit_expr(), emit_var(), emit_read(), emit_assign(), 
                    emit_while(), emit_if(), emit_call(), and emit_return()
                - Modified all the helper functions so that they can deal with the differnet node types properly
*/

/* 
    Create proper MIPS code and place it in the appropriated opened file
*/
#include "emit.h"
#include "ast.h"
#include "symtable.h"
#include <string.h>
#include <stdlib.h>

char * function_name; // Use to store the function's name and compare with main

// In file prototype
// This part is the declaration of all the functions
// This function takes node pointer, and does the proper actions according to different nodetypes
void emit_ast(ASTnode *p, FILE *fp); 
void emit_function_dec(ASTnode *p, FILE *fp); // This function deals with function declaration
void emit_function_dec(ASTnode * p, FILE * fp); // This function deals with writing strings or variables
void emit_write(ASTnode * p, FILE * fp);
// Need to fix AND and OR
void emit_expr(ASTnode * p, FILE * fp); // This function deals with expressions that users provide
void emit_var(ASTnode * p, FILE * fp); // This function deals with new variables 
void emit_read(ASTnode * p, FILE * fp); // This function deals with reading stuffs
void emit_assign(ASTnode * p, FILE * fp); // This function deals with assignment statements
void emit_while(ASTnode * p, FILE * fp); // This function deals with iteration statements
void emit_if(ASTnode * p, FILE * fp); // This function deals with selection statements
void emit_call(ASTnode * p, FILE * fp); // This function deals with function calls
// Working on it
void emit_return(ASTnode * p, FILE * fp); // This function deals with return statements

// PRE: Pointer to ASTnode and pointer to file
// POST: All MIPS code directly and through helper functions prints in the file via fp
void EMIT(ASTnode * p, FILE * fp) { // Start of EMIT()
    // If either or both of the parameters are NULL, BARF
    if (p == NULL) {
        return;
    }
    if (fp == NULL) {
        return;
    }
    // Always specify file when doing fprintf
    // Print out the header parts of .asm
    fprintf(fp, "#Compilers MIPS code \n"); 
    fprintf(fp, ".data   \n\n");
    // Print out the write strings if there's any using EMIT_STRINGS()
    EMIT_STRINGS(p, fp); 
    fprintf(fp, "\n.align 2 \n\n");
    // Print out the write strings if there's any using EMIT_GLOBALS()
    EMIT_GLOBALS(p, fp);
    fprintf(fp, "\n.text   \n\n");
    fprintf(fp, ".globl main  \n\n");
    emit_ast(p,fp); // Call emit_ast to deal with the rest of functions
} // End of EMIT()

// Create a helper function
// PRE: possible label, command, comment, and file pointer
// POST: formatted output to the file
void emit(FILE * fp, char * label, char * command, char * comment) { // Start of emit()
    if (strcmp("", comment) == 0) { // When there's no comment
        if (strcmp("", label) == 0) { // And when there's no label
            fprintf(fp, "\t%s\t\t\n", command); // Print out the command with specific format
        } else { // When there's label (but still no comment)
            fprintf(fp, "%s: \t%s\t\t\n", label, command); // Print out the command and label with specific format
        }
    } else { // When there's comment
        if (strcmp("", label) == 0) { // And when there's no label
            fprintf(fp, "\t%s\t\t# %s\n", command, comment); // Print out the command and comment with specific format
        } else { // When there's label (but still no comment)
            fprintf(fp, "%s: \t%s\t\t# %s\n", label, command, comment); // Print out the command, label, and comment with specific format
        }
    }
} // Start of emit()

// PRE: Pointer to astnode and pointer to file
// POST: Main driver for walking our AST tree to produce
//       MIPS code in the file
void emit_ast(ASTnode *p, FILE *fp) { // Start of function
    // Print A_DEC_LIST and A_FUNDEC only
    // If node pointer is NULL, BARF
    if (p == NULL) {
        return;
    }
    // printf("Print my node type %d!\n", p->nodetype); // For debug
    // Switch cases for different node types
    // Call the functions for each nodes
    switch (p->nodetype) { // Start of switch
        case A_DEC_LIST: 
            emit_ast(p->s1, fp);
            emit_ast(p->s2, fp);
            break;

        case A_STMT_LIST: 
            emit_ast(p->s1, fp);
            emit_ast(p->s2, fp);
            break;

        case A_WRITE: 
            emit_write(p, fp);
            break;

        case A_READ: 
            emit_read(p, fp);
            break;

        case A_RETURN: 
            emit_return(p, fp);
            break;

        case A_VARDEC: 
            emit_ast(p->s1, fp);
            emit_ast(p->s2, fp);
            break;

        case A_FUNDEC: 
            emit_function_dec(p, fp);
            break;

        case A_ASSIGN: 
            emit_assign(p, fp);
            break;

        case A_VAR: 
            // emit_var(p, fp);
            break;

        case A_EXPRSTMT:
            emit_expr(p->s1, fp);
            break;

        case A_COMPOUND:
            emit_ast(p->s2, fp);
            break;

        case A_ITERATION:
            emit_while(p, fp);
            break;

        case A_SELECTION:
            emit_if(p, fp);
            break;

        case A_CALL:
            emit_call(p, fp);
            break;
        
        default: 
            printf("emit_ast() unknown nodetype %d \n", p->nodetype);
            exit(1);
    } // End of switch
} // End of function

// PRE: Pointer to A_FUNDEC node and pointer to file
// POST: MIPS code for function, using emit_ast as helper
void emit_function_dec(ASTnode *p, FILE *fp) { // Start of emit_function_dec()
    char s[100]; // To print string with data on it if needed
    int count = 0;
    function_name = p->name;

    // Print these for every function
    emit(fp, p->name, "", "START OF FUNCTION");
    fprintf(fp, "\n");
    sprintf(s, "subu $a0, $sp, %d", p->symbol->offset * WSIZE); 
    emit(fp, "", s, "adjust the stack for function setup");
    emit(fp, "", "sw $sp, ($a0)", "remember old SP");
    emit(fp, "", "sw $ra, 4($a0)", "remember current Return address");
    emit(fp, "", "move $sp, $a0", "adjust the stack pointer");
    fprintf(fp, "\n\n");
    
    // Point to PARAM
    ASTnode * paramP = p->s1; 
    while (paramP != NULL) { // If there are parameters, print this line out
        sprintf(s, "sw $t%d, %d($sp)", count, paramP->symbol->offset * WSIZE); 
        emit(fp, "", s, "Load temp variable int formal paramter");
        count++;
        paramP = paramP->s1;
    }

    // Deal with compound statement
    emit_ast(p->s2, fp); // Calls for compound stmt

    // Do at the end of every function call
    if (strcmp(p->name ,"main") == 0) { // When it's  main, print out these lines
        emit(fp, "", "li $a0, 0", "RETURN has no specified value set to 0");
        emit(fp, "", "lw $ra 4($sp)", "restore old environment RA");
        emit(fp, "", "lw $sp ($sp)", "Return from function store SP");
        fprintf(fp, "\n");
        emit(fp, "", "li $v0, 10", "Exit from Main we are donem");
        emit(fp, "", "syscall", "EXIT everything");
    } else { // When it's not main, print out these lines
        emit(fp, "", "li $a0, 0", "RETURN has no specified value set to 0");
        emit(fp, "", "lw $ra 4($sp)", "restore old environment RA");
        emit(fp, "", "lw $sp ($sp)", "Return from function store SP");
        fprintf(fp, "\n");
        emit(fp, "", "jr $ra", "Return from function store SP");
    }
} // End of emit_function_dec()

// PRE: Pointer to a write node and pointer to file
// POST: MIPS code will perform WRITE
void emit_write(ASTnode * p, FILE * fp) { // Start of emit_write()
    char s[100]; // To print string with data on it if needed
    // To write string and expression
    if (p->name != NULL) { // For string, print out these lines and label
        emit(fp, "", "li $v0, 4", "print a string");
        sprintf(s, "la $a0, %s", p->label);
        emit(fp, "", s, "print fetch string location");
        emit(fp, "", "syscall", "Perform a write string");
        fprintf(fp, "\n\n");
    } else { // For expression, call emit_expr for that node and print out these lines
        emit_expr(p->s1, fp);
        emit(fp, "", "li $v0 1", "Print the number");
        emit(fp, "", "syscall", "system call for print number");
        fprintf(fp, "\n\n");
    }
} // End of emit_write()

// PRE: Pointer to a read node and pointer to file
// POST: MIPS code will perform READ
void emit_read(ASTnode * p, FILE * fp) { // Start of emit_read()
    emit_var(p->s1, fp); // Call emit_var() for the variable
    // Print out these lines and commands
    emit(fp, "", "li $v0 5", "read a number from input"); 
    emit(fp, "", "syscall", "reading a number");
    emit(fp, "", "sw $v0, ($a0)", "store the READ into a mem location");
    fprintf(fp, "\n");
} // End of emit_read()

// PRE: Pointer to a assignment node and pointer to file
// POST: MIPS code will perform assignment statement
void emit_assign(ASTnode * p, FILE * fp) { // Start of emit_assign()
    char s[100]; // To print string with data on it if needed
    // For expression part (which is s2)
    emit_expr(p->s2, fp);
    sprintf(s, "sw $a0 ,%d($sp)", p->symbol->offset * WSIZE);
    emit(fp, "", s, "Assign store RHS temporarily");

    // For variable part (which is s2)
    emit_var(p->s1, fp);
    sprintf(s, "lw $a1 %d($sp)", p->symbol->offset * WSIZE);
    emit(fp, "", s, "Assign get RHS temporarily");
    emit(fp, "", "sw $a1 ($a0)", "Assign place RHS into memory");
} // End of emit_assign()

// PRE: Pointer to WHILE node and pointer to file
// POST: MIPS code for while loop, using emit_expr() and emit_ast() as helpers
void emit_while(ASTnode * p, FILE * fp) { // Start of emit_while()
    char s[100]; // To print string with data on it if needed
    // Create 2 label variables to store labels
    char * label1;
    char * label2;

    label1 = createLable();
    emit(fp, label1, "", "WHILE TOP target");
    // s1 -> expr
    // s2 -> stmt
    emit_expr(p->s1, fp); // Call emit_expr() for s1 expression
    
    // Branch out if expression is false
    label2 = createLable();
    sprintf(s, "beq $a0 $0 %s", label2);
    emit(fp, "", s, "WHILE branch out");

    emit_ast(p->s2, fp); // Call emit_ast() for s2 statement list

    sprintf(s, "j %s", label1);
    emit(fp, "", s, "WHILE Jump back"); // Jumpback if expression is true
    
    emit(fp, label2, "", "End of WHILE");
} // End of emit_while()

// PRE: Pointer to IF node and pointer to file
// POST: MIPS code for if statement, using emit_expr() and emit_ast() as helpera
void emit_if(ASTnode * p, FILE * fp) { 
    // Prototype: T_IF Expression T_THEN Statement T_ENDIF
    // A_SEL->s1->Expr, s2->A_IF; A_IF->s1->Stmt for then
    char s[100]; // To print string with data on it if needed
    // Create 2 label variables to store labels
    char * label1;
    char * label2;

    emit_expr(p->s1, fp);  // Call emit_expr() for s1 expression
    label1 = createLable();
    sprintf(s, "beq $a0 $0 %s", label1);
    emit(fp, "", s, "IF branch to else part");
    fprintf(fp, "\n");
    emit(fp, "", "", "the positive portion of IF");

    emit_ast(p->s2->s1, fp); // Call emit_ast() for s2->s1

    label2 = createLable();
    sprintf(s, "j %s", label2);
    emit(fp, "", s, "IF S1 end");

    emit(fp, label1, "", "ELSE target");
    fprintf(fp, "\n");
    emit(fp, "", "", "the negative  portion of IF if there is an else");
    emit(fp, "", "", "otherwise just these lines");

    // A_SEL->s1->Expr, s2->A_IF
    // A_IF->s1->Stmt for then, s2->Stmt for else
    if (p->s2->s2 != NULL) { // If there's else part
        emit_ast(p->s2->s2, fp); // Call emit_ast() for else statements
    }

    emit(fp, label2, "", "End of IF ");

}

// PRE: Pointer to CALL node and pointer to file
// POST: MIPS code for call statement, using emit_expr() as helper
void emit_call(ASTnode * p, FILE * fp) {
    // Prototype: T_ID '(' Args ')'
    char s[100]; // To print string with data on it if needed

    emit(fp, "", "", "Setting Up Function Call");
    emit(fp, "", "", "evaluate  Function Parameters");

    // To make sure that the amount of arguments is in proper range
    int count = 0;

    ASTnode * paramPRT = p -> s1; // Parameters
    // Check to see if there's argument list
    while (paramPRT != NULL ) { // Start of while loop
        emit_expr(paramPRT->s1, fp); // Call expr with number
        sprintf(s, "sw $a0, %d($sp)", paramPRT->symbol->offset * WSIZE); 
        emit(fp, "", s, "Store call Arg temporarily");
        fprintf(fp, "\n");
        paramPRT = paramPRT->s2;
    } // End of while loop

    emit(fp, "", "", "place   Parameters into T registers");

    // Check argument list one more time for another command
    ASTnode * argumentPRT = p -> s1; 
    int counterArg = 0;
    // Node type A_ARGLIST
    while (argumentPRT != NULL) { // Start of while loop
        // While there's argument, print out these
        sprintf(s, "lw $a0, %d($sp)", argumentPRT->symbol->offset * WSIZE);
        emit(fp, "", s, "pull out stored  Arg ");

        sprintf(s, "move $t%d, $a0", counterArg);
        emit(fp, "", s, "move arg in temp ");

        count++; // Update the amount of arguments
        if (count > 8){ // If there are more than 8 arguments, BARF
            printf("Too many arguments! It should be less than 8");
            exit(1);
        }
        argumentPRT = argumentPRT->s2; 
        counterArg++;
    } // End of while loop

    // Print out these at the end of call 
    fprintf(fp, "\n");
    sprintf(s, "jal %s", p->name);
    emit(fp, "", s, "Call the function");
    fprintf(fp, "\n\n");
}

// PRE: Pointer to RETURN node and pointer to file
// POST: MIPS code for Return statement
void emit_return(ASTnode * p, FILE * fp) {
    // Main
        // Main return
        // Main return expr
    // Not main
        // Not main return
        // Not main return expr
    char s[100];

    if (p->s1 == NULL) { // When there's no expression
		emit(fp,"","li $a0, 0", "RETURN has no specified value set to 0");
	
		emit(fp,"","lw $ra ($sp)", "restored old environment RA");
		sprintf(s, "lw $sp %d($sp)", WSIZE); 
		emit(fp,"",s,"Return from function store SP");
		fprintf(fp,"\n");
		
		if(strcmp(function_name, "main") == 0){ // If it's under main function
			emit(fp, "", "li $v0, 10", "Exit from Main we are done");
			emit(fp, "", "syscall\t", "Exit everything");
		}
		else{ // If it's not main function
			emit(fp, "", "jr $r\t", "return to the caller");
		}
    } else { // Return with expression
        emit_expr(p->s1, fp);
		sprintf(s, "lw $ra %d($sp)", WSIZE);
		emit(fp,"",s,"restore old environment RA");
		emit(fp,"","lw $sp ($sp)", " Return from function store SP");
		fprintf(fp,"\n");

        if (strcmp(function_name, "main") == 0) { // When it's main function
			emit(fp, "", "li $v0, 10", "Exit from Main we are done");
			emit(fp, "", "syscall\t", "Exit everything");
        } else { // When it's not main function
             emit(fp, "", "jr $ra", "return to the caller");
        }
    }
}

// PRE: Pointer to a expr tree component ie. A_EXPR, A_NUM, A_CAL
// POST: $a0 will have value set by the genreated MIPS
void emit_expr(ASTnode * p, FILE * fp) { // Start of emit_expr()

    if (p==NULL) { // Start of IF
        printf("Illegal use of EMIT_EXPR with NULL pointer\n");
        exit(1);
    }// End of IF

    char s[100]; // To print string with data on it if needed

    // BASE CASES of Nodetypes:
    switch (p->nodetype) { // start of switch of base cases
        case A_BOOLEAN: // Since it's same as A_NUM we don't need to write out the code
        case A_NUM: 
            sprintf(s, "li $a0, %d", p->value);
            emit(fp, "", s, "Expression is constant");
            return;
            break;

        case A_CALL:
            emit_call(p, fp);
            return;
            break;

        case A_EXPR: 
            break;

        case A_VAR: 
            emit_var(p, fp);
            if (p->value == 0) { 
                emit(fp, "", "lw $a0, ($a0)", "Expression is a VAR");
            }
            return;
            break;

        default: 
            printf("emit_expr base case not known %d\n", p->nodetype);
            exit(1);
    } // end of switch of base cases

    // Print these out when ever there's expression with some operators
    emit_expr(p->s1, fp); // Check for additive expression

    sprintf(s, "sw $a0, %d($sp)", p->symbol->offset * WSIZE);
    emit(fp, "", s, "expression store LHS temporarily");

    emit_expr(p->s2, fp); // Check for term
    
    emit(fp, "", "move $a1, $a0", "right hand side needs to be a1");

    sprintf(s, "lw $a0, %d($sp)", p->symbol->offset * WSIZE);
    emit(fp, "", s, "expression restore LHS from memory");

    switch (p->operator) { // Start of switch for operators

        case A_PLUS:
            emit(fp, "", "add $a0, $a0, $a1", "EXPR ADD");
            return;
            break;

        case A_MINUS:
            emit(fp, "", "sub $a0, $a0, $a1", "EXPR SUB");
            return;
            break;

        case A_TIMES:
            emit(fp, "", "mult $a0 $a1", "EXPR MULT");
            emit(fp, "", "mflo $a0", "EXPR MULT");
            return;
            break;

        case A_DIV:
            emit(fp, "", "div $a0 $a1", "EXPR DIV");
            emit(fp, "", "mflo $a0", "EXPR DIV");
            return;
            break;

        case A_LT:
            emit(fp, "", "slt $a0, $a0, $a1", "EXPR Less than");
            return;
            break;

        case A_GT:
            emit(fp, "", "slt $a0, $a1, $a0", "EXPR Greater than");
            return;
            break;

        case A_GEQ:
            emit(fp, "", "add $a0 ,$a0, 1", "EXPR  ADD GE");
            emit(fp, "", "slt $a0, $a1, $a0", "EXPR Greaterthan");
            return;
            break;

        case A_LEQ:
            emit(fp, "", "add $a1 ,$a1, 1", "EXPR LE add one to do compare");
            emit(fp, "", "slt $a0 ,$a0, $a1", "EXPR LE");
            return;
            break;

        case A_EQT:
            emit(fp, "", "slt $t2 ,$a0, $a1", "EXPR EQUAL");
            emit(fp, "", "slt $t3 ,$a1, $a0", "EXPR EQUAL");
            emit(fp, "", "nor $a0 ,$t2, $t3", "EXPR EQUAL");
            emit(fp, "", "andi $a0 , 1", "EXPR EQUAL");
            return;
            break;

        case A_NEQ:
            emit(fp, "", "slt $t2 ,$a0, $a1", "EXPR NOT EQUAL");
            emit(fp, "", "slt $t3 ,$a1, $a0", "EXPR NOT EQUAL");
            emit(fp, "", "or $a0 ,$t2, $t3", "EXPR NOT EQUAL");
            return;
            break;

        case A_AND: 
            emit(fp, "", "and $a0, $a0, $a1", "EXPR AND");
            return;
            break;

        case A_OR:
            emit(fp, "", "or $a0, $a0, $a1", "EXPR OR");
            return;
            break;

        default: 
            printf("emit_expr operator not known \n");
            exit(1);

 
    } // End of switch for operators
} // End of emit_expr()

// PRE: Pointer to A_VAR
// POST: $a0 will be memory location of variable
void emit_var(ASTnode * p, FILE * fp) { // Start of emit_var()
    // Variables are global or local
    // Array or not

    // For global, start point is where the label is located
    // For local, start point is stack pointer plus offset (*WSIZE)

    // For array we have to add internal ffset to these values
    char s[100];
    if (p->symbol->SubType == SYM_ARRAY) { // That means it's an array
        if (p->s1 != NULL) { 
            emit_expr(p->s1, fp);
            emit(fp, "", "move $a1, $a0", "VAR copy index array in a1");
            sprintf(s, "sll $a1 $a1 %d", LOB_WSIZE);
            emit(fp, "", s, "muliply the index by wordszie via SLL");
        }
     }
    if (p->symbol->level == 0) { // When it's global
            sprintf(s, "la $a0, %s", p->name);
            emit(fp, "", s, "EMIT Var global variable");
    } else { // When it's local array ?
        emit(fp, "", "move $a0 $sp", "VAR local make a copy of stackpointer");
        sprintf(s, "addi $a0 $a0 %d", p->symbol->offset * WSIZE);
        emit(fp, "", s, "VAR local stack pointer plus offset");
    }
            
    if (p->symbol->SubType == SYM_ARRAY) { // Global Array
        emit(fp, "", "add $a0 $a0 $a1", "VAR array add internal offset");
    }

} // End of emit_var()

// PRE: Pointer to global variables
// POST: Print out the MIPS code for all global vardec
void EMIT_GLOBALS(ASTnode * p, FILE * fp) { // Start of EMIT_GLOBALS()
    if (p == NULL) {
        return;
    }
    if (p->nodetype == A_VARDEC && p->symbol->level== 0) { // When it's a vardec and it's level is 0
        fprintf(fp, "%s", p->name); // Print out the variable name
        fprintf(fp, ":   .space %d # global variable\n", p->symbol->mysize * WSIZE); // Print out the size
        if (p->s1 == NULL) { // If it doesn't have s1, return
            return;
        } // Recursively call this function by it's s1 (when there is any)
    }
    EMIT_GLOBALS(p->s1, fp);
    EMIT_GLOBALS(p->s2, fp);
} // End of EMIT_GLOBALS()

// PRE: Pointer to writing string node
// POST: Print out the MIPS code for the writing string under .data
void EMIT_STRINGS(ASTnode * p, FILE * fp) { // Start of EMIT_STRINGS()
    if (p == NULL) { // If nothing in p, return (base case)
        return;
    }
    if (p->nodetype == A_WRITE && p->name != NULL) { // When it's a write node and there's a string
        p -> label = createLable();
        fprintf(fp, "%s: .asciiz    %s\n", p->label, p->name); // Print out the label and string
    }
    EMIT_STRINGS(p->s1, fp); // Recursively call this function by it's s1
    EMIT_STRINGS(p->s2, fp); // Recursively call this function by it's s2
} // End of EMIT_STRINGS()