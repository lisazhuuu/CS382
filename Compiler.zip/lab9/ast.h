 /*        Mingfang Zhu
            Nov 18, 2023
            Lab9

            Description of Program:
                This lab is to build a compiler program
                It should input from users, parse it, and create machine code based the input and rules
                It also creates symbol table to keep track of all the functions, variables, etc.

            Description of File: 
                This file is the head file of ast.c, and it declares all the methods that will be used there
                    Including check_params(), createLabel(), ASTCreateNode(), and PT().
                It also declared all the nodetypes, datatypes, operators, and ASTnodetypes for the nodes. 
                There are all the attributes of each node. 
                Also, there it provides connection between ast files and symtable files by struct SymbTab *sybol.

            Changes: 
                - Declared the new method createTable() that was just added in the c file
                - Added struct SymbTab *symbol into struct ASTnodetype so that we can accept the symtable elements by nodes
*/

/*      Mingfang Zhu
        Oct 29, 2023
        Lab7

        Description: 
                - Add symbol table code to the semantic action set. 
                - Ensure that used variables have been declared. 
                - Assign new symbols to intermeidate values in expressions
                - Add type checking to not mix void and int
        
        This file provides the definitions and declarations of methods and structs for ast.c

        Changes: 
            - Include "symtable.h"
            - Add datatype A_UNKNOWN
            - Add declaration of check_param method
*/
/*      Mingfang Zhu
        Oct 13, 2023
        Lab6

        This lab checks whether the syntax of program is correct, and creates a simple Abstract Syntax Tree.
        This file is the header file for ast.c. It defines ASTtype, Datatypes, operators, and struct ASTnodetype.
        
        - Add more types to ASTtype
        - Add boolean as datatype
        - Add more operators
*/

/* Abstract syntax tree code
Header file
Shaun Cooper January 2022
*/
#include<stdio.h>
#include<malloc.h>
#ifndef AST_H
#define AST_H

extern int mydebug;

/* define the enumerated types for the AST. THis is used to tell us what
sort of production rule we came across */
// Declare A_Tokens
enum ASTtype 
{
    A_VARDEC,
    A_LOCAL_DEC,
    A_VAR,
    A_DEC_LIST,
    A_FUNCTIONDEC,
    A_FUNDEC,
    A_STMT_LIST,
    A_PARAMLIST,
    A_CALL,
    A_ARGLIST,
    A_ARGS,
    A_COMPOUND,
    A_WRITE,
    A_NUMBER,
    A_EXPR,
    A_NUM,
    A_ASSIGN,
    A_ITERATION,
    A_PARAMS,
    A_PARAM,
    A_SELECTION,
    A_READ,
    A_RETURN,
    A_TRUE,
    A_FALSE,
    A_EXPRSTMT,
    A_BOOLEAN,
    A_IFSTMT
    //missing
};

enum DataTypes 
{
    A_INTTYPE,
    A_VOIDTYPE,
    A_BOOTYPE,
    A_UNKNOWN
};

enum OPERATORS 
{
    A_PLUS,
    A_MINUS,
    A_TIMES,
    A_DIV,
    A_LEQ,
    A_LT,
    A_GT,
    A_GEQ,
    A_NEQ,
    A_EQT,
    A_NOT,
    A_AND,
    A_OR 
};

/* define a type AST node which will hold pointers to AST structs that will
allow us to represent the parsed code
*/
typedef struct ASTnodetype
{
    enum ASTtype nodetype;
    enum OPERATORS operator;
    enum DataTypes datatype;
    char * name;
    char * label;
    int value;
    struct SymbTab *symbol; // So ASTNode can access symbol table
    ///.. missing
    struct ASTnodetype *s1,*s2; /* used for holding IF and WHILE components --
    not very descriptive */
} ASTnode;
int check_params(ASTnode *formals, ASTnode *actuals);
/* uses malloc to create an ASTnode and passes back the heap address of the newley
created node */
char * createLable(); // This method is for ast.c to create and print temporary label on .asm file
ASTnode *ASTCreateNode(enum ASTtype mytype);
void PT(int howmany);
ASTnode *program; // pointer to the tree

/* Print out the abstract syntax tree */
void ASTprint(int level,ASTnode *p);
#endif // of AST_H
