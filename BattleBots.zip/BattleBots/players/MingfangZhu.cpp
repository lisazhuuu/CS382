#include "MingfangZhu.h"
#include <iostream>
#include <stdlib.h> // for random()
#include <cmath>

//
// Constructor
// - must invoke Player constructor as shown
//
MingfangZhu::MingfangZhu(unsigned int id, Position start, Position goal)
      : Player(id, start, goal)
{
    dir.x = 0;
    dir.y = 0;
    pos = start;
    color = random() & 0xffffff00;
}

//
// Draw my player image
//

//
// Update my position
// - this bot just heads for its goal without doing anything else
//

int player;
int dx, dy;
bool attackMode = false;

void MingfangZhu::update(const GameArea& area,
                           const std::vector<Prize const*> prizes,
                           const std::vector<Obstacle const*> obstacles,
                           const std::vector<PlayerInfo const*> players)
{
Position target = goal;
Position tempTarget;

target.x = goal.x;
target.y = goal.y;

   if(goal.x >= pos.x && goal.y >= pos.y){
      player = 0;
   }else if(goal.x <= pos.x && goal.y >= pos.y){
      player = 1;
   }else if(goal.x >= pos.x && goal.y <= pos.y){
      player = 2;
   }else{
      player = 3;
   }

const int safeDist = 35;
for (auto player : players){
   if(!(player->id == id)){
      double playerDist = std::sqrt(std::pow((double)std::max(player->pos.x, pos.x) - (double)std::min(player->pos.x, pos.x), 2) + std::pow((double)std::max(player->pos.y, pos.y) - (double)std::min(player->pos.y, pos.y), 2));
         if(playerDist < safeDist){
            attackMode = true;
            break;
         }else{
            attackMode = false;
         }
      }
      }
     

int searchRadius = 400;
double highPrize = 0;
       for (auto prize : prizes){
        if (!(prize->claimed)){
            double dist = std::sqrt(std::pow((double)std::max(prize->pos.x, pos.x) - (double)std::min(prize->pos.x, pos.x), 2) + std::pow((double)std::max(prize->pos.y, pos.y) - (double)std::min(prize->pos.y, pos.y), 2));
           
            if(dist < searchRadius){
               double prizeRatio = prize->value/dist;
               if(prizeRatio > highPrize){
                  highPrize = prizeRatio;
                  tempTarget = prize->pos;
                  //std::cerr << "Found new best prize! " <<  prize->value << " / " << dist  << " = " << prizeRatio << "\n";
              }
              //std::cerr << "Heading to best prize! With score: " << highPrize << "\n";
              target = tempTarget;
            }
        }
       }
       
    for(auto obstacle: obstacles){
      //int obstacleWidth = obstacle->high.x - obstacle->low.x;
      //int obstacleHeight = obstacle->high.y - obstacle->low.y;

      // top left to bottom right (++)
      if(player == 0){
      if(((pos.y + 25 >= obstacle->low.y) && (pos.y + 25 <= obstacle->high.y)) || ((pos.x + 25>= obstacle->low.x) && (pos.x + 25 <= obstacle->high.x))){          
            if(((pos.y >= obstacle->low.y) && (pos.y <= obstacle->high.y + 25))){
               if(((pos.x + 25 >= obstacle->low.x) && (pos.x - 25 <= obstacle->high.x))){
                  target.x = pos.x;
                  target.y = pos.y + 3;
                
                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
               }
            }
              if((pos.x >= obstacle->low.x) && (pos.x <= obstacle->high.x + 25)){
              if(((pos.y + 25 >= obstacle->low.y) && (pos.y - 25 <= obstacle->high.y))){
                  target.y = pos.y;
                  target.x = pos.x + 3;

                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
                   }
                   }
            }
            }
      // top right to bottom left (-+)
      if(player == 1){
            if(((pos.y + 25 >= obstacle->low.y) && (pos.y <= obstacle->high.y)) || ((pos.x >= obstacle->low.x) && (pos.x - 25 <= obstacle->high.x))){          
            if(((pos.y >= obstacle->low.y) && (pos.y <= obstacle->high.y + 25))){   //check this to see if this object is even close to you
               if(((pos.x >= obstacle->low.x - 19) && (pos.x <= obstacle->high.x + 19))){
                  target.x = pos.x;
                  target.y = pos.y + 3;
                
                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
               }
            }
              if((pos.x >= obstacle->low.x) && (pos.x <= obstacle->high.x + 16)){   //check this
              if(((pos.y + 25 >= obstacle->low.y) && (pos.y + 25 <= obstacle->high.y))){
                  target.y = pos.y;
                  target.x = pos.x - 3;

                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
                   }
                   }
            }
            }

            // bottom left to top right (+-)
            if(player == 2){
            if(((pos.y - 25 >= obstacle->low.y) && (pos.y - 25 <= obstacle->high.y)) || ((pos.x + 25>= obstacle->low.x) && (pos.x + 25 <= obstacle->high.x))){          
            if(((pos.y >= obstacle->low.y - 25) && (pos.y <= obstacle->high.y))){   //check this
               if(((pos.x + 25 >= obstacle->low.x) && (pos.x - 25 <= obstacle->high.x))){
                  target.x = pos.x;
                  target.y = pos.y - 3;
                
                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
               }
            }
              if((pos.x >= obstacle->low.x) && (pos.x <= obstacle->high.x + 25)){
              if(((pos.y + 25 >= obstacle->low.y) && (pos.y - 25 <= obstacle->high.y))){
                  target.y = pos.y;
                  target.x = pos.x + 3;

                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
                   }
                   }
            }
            }


            // bottom right to top left (--)
            if(player == 3){
            if(((pos.y - 25 >= obstacle->low.y) && (pos.y - 25 <= obstacle->high.y)) || ((pos.x - 25>= obstacle->low.x) && (pos.x - 25 <= obstacle->high.x))){          
            if(((pos.y >= obstacle->low.y - 25) && (pos.y <= obstacle->high.y))){   //check this
               if(((pos.x - 25 >= obstacle->low.x) && (pos.x - 25 <= obstacle->high.x))){
                  target.x = pos.x;
                  target.y = pos.y - 3;
                
                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
               }
            }
              if((pos.x >= obstacle->low.x - 25) && (pos.x <= obstacle->high.x)){   //check this
              if(((pos.y - 25 >= obstacle->low.y) && (pos.y - 25 <= obstacle->high.y))){
                  target.y = pos.y;
                  target.x = pos.x - 3;

                  dx = target.x - pos.x;
                  dy = target.y - pos.y;
                  if (dx > MAX_MOVE)
                     dx = MAX_MOVE;
                  if (dx < -MAX_MOVE)
                     dx = -MAX_MOVE;
                  if (dy > MAX_MOVE)
                     dy = MAX_MOVE;
                  if (dy < -MAX_MOVE)
                     dy = -MAX_MOVE;
                
                  pos.x += dx;
                  pos.y += dy;
                
                  return;
                   }
                   }
            }
            }
    }
            dx = target.x - pos.x;
            dy = target.y - pos.y;
            if (dx > MAX_MOVE)
               dx = MAX_MOVE;
            if (dx < -MAX_MOVE)
               dx = -MAX_MOVE;
            if (dy > MAX_MOVE)
               dy = MAX_MOVE;
            if (dy < -MAX_MOVE)
               dy = -MAX_MOVE;
             
            pos.x += dx;
            pos.y += dy;

        
       }

   
void MingfangZhu::draw()
{
    fl_color(color);
    fl_pie(pos.x - PLAYER_SIZE / 2, pos.y - PLAYER_SIZE / 2, PLAYER_SIZE,
            PLAYER_SIZE, 0, 360);
}


void MingfangZhu::prizeClaimed(const Prize& prize)
{
    std::cerr << "Hey I " << name() << " claimed a prize of value " << prize.value << "!\n";
}
void MingfangZhu::YO()
{
    std::cerr << "Player: " << player << "\n";
}